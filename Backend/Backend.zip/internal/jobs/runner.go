package jobs

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"

	"reverb/backend-gin/internal/util"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

func StartJob(c *gin.Context) (string, error) {
	form, err := c.MultipartForm()
	if err != nil {
		return "", err
	}

	files := form.File["files"]

	if len(files) == 0 {
		return "", errors.New("files[] missing")
	}

	var p ReverbParams
	if err := json.Unmarshal([]byte(c.PostForm("params")), &p); err != nil {
		return "", err
	}

	id := uuid.NewString()
	inDir := filepath.Join(workDir, id, "in")
	outDir := filepath.Join(workDir, id, "out")
	_ = os.MkdirAll(inDir, 0755)
	_ = os.MkdirAll(outDir, 0755)

	for _, fh := range files {
		if err := saveFile(fh, filepath.Join(inDir, fh.Filename)); err != nil {
			return "", err
		}
	}

	var outArtifact string
	if len(files) == 1 {
		outArtifact = filepath.Join(outDir, files[0].Filename+"_reverb.wav")
		newJob(id, outArtifact)
		go runSingle(id, filepath.Join(inDir, files[0].Filename), outArtifact, p)
	} else {
		outArtifact = filepath.Join(workDir, id, "result.zip")
		newJob(id, outArtifact)
		go runBatch(id, inDir, outDir, outArtifact, p)
	}
	return id, nil
}

func runSingle(id, inFile, outFile string, p ReverbParams) {
	args := []string{
		"--input_file", inFile, "--output_file", outFile,
		"--room", f(p.RoomSize), "--damp", f(p.Damping),
		"--wet", f(p.WetLevel), "--dry", f(p.DryLevel), "--width", f(p.Width),
	}
	execAndTrack(id, args, "")
}

func runBatch(id, inDir, outDir, zipPath string, p ReverbParams) {
	args := []string{
		"--input_folder", inDir, "--output_folder", outDir,
		"--room", f(p.RoomSize), "--damp", f(p.Damping),
		"--wet", f(p.WetLevel), "--dry", f(p.DryLevel), "--width", f(p.Width),
	}
	execAndTrack(id, args, zipPath)
}

func execAndTrack(id string, args []string, zipTarget string) {
	cmd := exec.Command("./ReverbApp", args...)
	stdout, _ := cmd.StdoutPipe()
	_ = cmd.Start()

	go parseProgress(id, stdout)

	err := cmd.Wait()
	if err == nil && zipTarget != "" {
		srcDir := strings.TrimSuffix(zipTarget, "result.zip") + "out"
		_ = util.ZipFolder(srcDir, zipTarget)
	}

	errStr := ""
	if err != nil {
		errStr = err.Error()
	}
	markDone(id, errStr)
}

func parseProgress(id string, r io.Reader) {
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		if strings.HasPrefix(scanner.Text(), "PROGRESS") {
			var pct int
			fmt.Sscanf(scanner.Text(), "PROGRESS %d", &pct)
			updateProgress(id, pct)
		}
	}
}

func saveFile(fh *multipart.FileHeader, dst string) error {
	src, err := fh.Open()
	if err != nil {
		return err
	}
	defer src.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, src)
	return err
}

func f(x float64) string { return strconv.FormatFloat(x, 'f', -1, 64) }
